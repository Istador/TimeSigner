/**
  * Changes the status to "Processing"
  * @param evt The event object from the FileReader
  */
function updateProgress(evt)
{
  document.getElementById('status').innerHTML = "Status: Processing";
}

/**
  * Displays an error
  * @param evt The event object from the FileReader
  */
function errorHandler(evt)
{
  document.getElementById('status').innerHTML = "Status: Error ("+evt.target.error.code+")";
}

/**
  * Reads a file as a binary string using the FileReader
  * @param file The file object
  * @param callback A callback function to which the file and the event object will be passed
  */
function readFile(file, callback)
{
  var reader = new FileReader();
  reader.onload = function(evt)
  {
    if (typeof callback=="function")
      callback(file, evt);
  };
  reader.onprogress = updateProgress;
  reader.onerror = errorHandler;
  
  reader.readAsBinaryString( file );
}

/**
  * Handles the file selection and displays the hash sums as HTML
  * @uses readFile
  */
function handleFileSelect()
{
  var input = document.getElementById("file_input");
  
  if ( typeof FileReader=="undefined" || !input.files)
  {
    alert("Your browser doesn't support the HTML 5 File API!");
    return;
  }
  
  var files = input.files;
  
  for (var i=0; i < files.length; i++)
  {
    readFile(input.files[i], function(file, evt)
    {            
      var hash = null;
      var hash_function = document.getElementById("hash_func").value;
      
      if (hash_function=="md5") hash = hex_md5( evt.target.result );
      else if (hash_function=="sha1") hash = hex_sha1( evt.target.result );
      else if (hash_function=="sha256") hash = hex_sha256( evt.target.result );
      else if (hash_function=="sha512") hash = hex_sha512( evt.target.result );
      
      var elListItem = document.createElement("li");
      var elFilename = document.createTextNode( file.name + " ("+hash_function.toUpperCase() +")" );

      var elMD5 = document.createTextNode( hash );
      
      elListItem.appendChild( elFilename );
      elListItem.appendChild(  document.createElement("br")  );
      elListItem.appendChild( elMD5 );
      document.getElementById("md5-list").appendChild( elListItem );
    });
  }
}

/**
  * Handles the onLoad event
  */
window.onload = function()
{
  document.getElementById("file_input").onchange = handleFileSelect;
}